
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Lotus, Feather, Scroll } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';
import CategoryCard from '@/components/CategoryCard';
import { getAllCategories } from '@/utils/data';

const Index = () => {
  const featuredCategories = getAllCategories().slice(0, 3);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-kashmir/10 via-sandalwood/10 to-saffron/5 z-0"></div>
        
        {/* Decorative Elements */}
        <div className="absolute top-20 right-10 w-64 h-64 rounded-full bg-gradient-to-br from-saffron/10 to-deepSaffron/5 blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-80 h-80 rounded-full bg-gradient-to-tr from-rudraksha/10 to-kashmir/5 blur-3xl"></div>
        
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="w-24 h-24 mx-auto mb-8 rounded-full bg-gradient-to-br from-saffron/20 to-deepSaffron/40 flex items-center justify-center">
              <span className="font-rozha text-4xl text-rudraksha">वे</span>
            </div>
            
            <h1 className="font-rozha text-4xl md:text-5xl lg:text-6xl mb-6">
              <span className="text-rudraksha">वेदा</span> <span className="text-saffron">AI</span> <span className="text-rudraksha">ज्ञान कोष</span>
            </h1>
            
            <p className="text-xl mb-8 text-foreground/80">
              Explore the ancient wisdom of Hindu sacred texts through the power of AI
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button asChild className="bg-gradient-to-r from-saffron to-deepSaffron hover:from-deepSaffron hover:to-saffron text-sandalwood/90 px-8 py-6 shadow-lg shadow-saffron/20 transition-all duration-300 hover:shadow-deepSaffron/30">
                <Link to="/explore" className="flex items-center gap-2">
                  <span>Explore All Granthas</span>
                  <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-saffron text-saffron hover:bg-saffron/10 shadow-sm">
                <Link to="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="ornate-divider mt-16 max-w-md mx-auto"></div>
      </section>
      
      {/* Featured Categories Section */}
      <section className="py-12 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-br from-sandalwood/5 to-kashmir/10 z-0"></div>
        <div className="container relative z-10">
          <div className="flex flex-wrap justify-between items-center mb-8">
            <h2 className="font-rozha text-3xl text-gradient-rudraksha">Featured Categories</h2>
            <Link to="/explore" className="flex items-center text-saffron hover:text-deepSaffron transition-all">
              View All <ChevronRight className="h-4 w-4 ml-1 group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCategories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Why Veda AI Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-kashmir/10 via-sandalwood/10 to-kashmir/5">
        <div className="container">
          <h2 className="font-rozha text-3xl text-gradient-rudraksha text-center mb-12">Why Veda AI?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-lg bg-sandalwood/10 backdrop-blur-sm border border-saffron/20 hover:border-saffron/40 transition-colors shadow-lg hover:shadow-xl group">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-saffron/20 to-saffron/40 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Scroll className="h-6 w-6 text-rudraksha" />
              </div>
              <h3 className="font-rozha text-xl mb-2 group-hover:text-saffron transition-colors">Ancient Wisdom</h3>
              <p className="text-foreground/70">Access the timeless knowledge of Hindu sacred texts in a modern, accessible format.</p>
            </div>
            
            <div className="p-6 rounded-lg bg-sandalwood/10 backdrop-blur-sm border border-saffron/20 hover:border-saffron/40 transition-colors shadow-lg hover:shadow-xl group">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-saffron/20 to-saffron/40 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Feather className="h-6 w-6 text-rudraksha" />
              </div>
              <h3 className="font-rozha text-xl mb-2 group-hover:text-saffron transition-colors">AI-Powered Insights</h3>
              <p className="text-foreground/70">Ask questions and receive detailed insights based on the ancient texts.</p>
            </div>
            
            <div className="p-6 rounded-lg bg-sandalwood/10 backdrop-blur-sm border border-saffron/20 hover:border-saffron/40 transition-colors shadow-lg hover:shadow-xl group">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-saffron/20 to-saffron/40 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Lotus className="h-6 w-6 text-rudraksha" />
              </div>
              <h3 className="font-rozha text-xl mb-2 group-hover:text-saffron transition-colors">Comprehensive Collection</h3>
              <p className="text-foreground/70">Explore Vedas, Puranas, Epics, and more - all in one place.</p>
            </div>
          </div>
          
          <div className="mt-12 flex justify-center">
            <div className="w-32 h-1 bg-gradient-to-r from-transparent via-saffron/50 to-transparent"></div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="mt-auto py-8 px-4 border-t-2 border-kashmir/30 bg-gradient-to-r from-sandalwood/20 to-kashmir/10">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center shadow-lg">
                <span className="text-sandalwood/90 font-semibold text-xs">वे</span>
              </div>
              <span className="font-rozha text-2xl text-gradient-rudraksha">Veda AI</span>
            </div>
            
            <div className="text-sm text-foreground/70">
              &copy; {new Date().getFullYear()} Veda AI ज्ञान कोष | <span className="font-kalam">Preserving the Ancient Wisdom of Hindu Scriptures</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;

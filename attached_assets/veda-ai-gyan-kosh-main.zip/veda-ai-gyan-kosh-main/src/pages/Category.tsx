
import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Grid, List, FilterX, ArrowRight, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Navbar from '@/components/Navbar';
import TextCard from '@/components/TextCard';
import { getCategoryById } from '@/utils/data';
import { useToast } from '@/hooks/use-toast';

const Category = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  const category = categoryId ? getCategoryById(categoryId) : undefined;
  
  useEffect(() => {
    if (!category && categoryId) {
      toast({
        title: "Category not found",
        description: "The category you're looking for doesn't exist.",
        variant: "destructive"
      });
      navigate('/');
    }
  }, [category, categoryId, navigate, toast]);
  
  if (!category) {
    return null;
  }

  const filteredTexts = category.texts.filter(text => 
    text.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    text.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-secondary/20">
      <Navbar />
      
      <div className="container py-8 animate-fade-in">
        <Button 
          variant="ghost" 
          className="mb-4 hover:bg-saffron/10 hover:text-saffron group transition-colors flex items-center"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-4 w-4 mr-2 group-hover:transform group-hover:-translate-x-1 transition-transform" />
          <span>Back to Explore</span>
        </Button>
        
        <div className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative">
              <h1 className="font-rozha text-3xl md:text-4xl mb-2 text-gradient-rudraksha">
                {category.name}
              </h1>
              <div className="absolute -bottom-1 left-0 h-0.5 w-24 bg-gradient-to-r from-rudraksha/80 via-saffron to-transparent"></div>
              <p className="text-lg text-foreground/80 max-w-2xl pt-3">
                {category.description}
              </p>
              <div className="mt-2 inline-flex items-center text-xs text-saffron/80 bg-saffron/10 px-3 py-1 rounded-full">
                <BookOpen className="h-3 w-3 mr-1" />
                {category.texts.length} sacred texts
              </div>
            </div>
            
            <div className="flex space-x-2 p-1.5 bg-kashmir/10 backdrop-blur-sm rounded-lg shadow-sm border border-kashmir/20">
              <Button 
                variant="ghost" 
                size="sm"
                className={`${viewMode === 'grid' ? 'bg-saffron/20 text-saffron' : ''} hover:bg-saffron/20 hover:text-saffron`}
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4 mr-1" />
                Grid
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                className={`${viewMode === 'list' ? 'bg-saffron/20 text-saffron' : ''} hover:bg-saffron/20 hover:text-saffron`}
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4 mr-1" />
                List
              </Button>
            </div>
          </div>
        </div>
        
        <div className="ornate-divider mb-8"></div>
        
        <div className="relative mb-8 max-w-xl group focus-within:scale-[1.01] transition-all duration-300">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground/50 group-focus-within:text-saffron transition-colors" size={18} />
          <Input 
            className="pl-10 border-kashmir/40 focus-visible:ring-saffron bg-sandalwood/10 shadow-sm focus-visible:shadow-md transition-all"
            placeholder={`Search within ${category.name}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0"
              onClick={() => setSearchQuery('')}
            >
              <FilterX size={14} />
            </Button>
          )}
        </div>
        
        {filteredTexts.length === 0 ? (
          <div className="text-center py-16 bg-sandalwood/10 backdrop-blur-sm rounded-xl border-2 border-dashed border-kashmir/30 animate-fade-in">
            <div className="w-16 h-16 mx-auto rounded-full bg-secondary/50 flex items-center justify-center mb-4">
              <Search className="h-6 w-6 text-foreground/40" />
            </div>
            <h3 className="text-lg font-medium mb-1 font-rozha">No texts found</h3>
            <p className="text-foreground/60">Try a different search query</p>
            <Button 
              variant="link" 
              className="mt-2 text-saffron hover:text-deepSaffron"
              onClick={() => setSearchQuery('')}
            >
              Clear search
            </Button>
          </div>
        ) : (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
              {filteredTexts.map((text) => (
                <TextCard key={text.id} categoryId={category.id} text={text} />
              ))}
            </div>
          ) : (
            <div className="space-y-4 animate-fade-in">
              {filteredTexts.map((text) => (
                <Link 
                  key={text.id}
                  to={`/text/${category.id}/${text.id}`}
                  className="flex items-center p-4 border-2 border-kashmir/30 rounded-lg hover:border-saffron/50 bg-sandalwood/10 backdrop-blur-sm hover:bg-gradient-to-r hover:from-kashmir/20 to-sandalwood/20 transition-all group relative overflow-hidden"
                >
                  <div className="absolute -right-12 -top-12 w-24 h-24 rounded-full bg-gradient-to-br from-saffron/10 to-saffron/5 group-hover:scale-150 transition-transform duration-700 ease-out opacity-0 group-hover:opacity-100"></div>
                  
                  <div className="w-10 h-10 rounded-full bg-saffron/20 flex items-center justify-center mr-4 group-hover:bg-gradient-to-br group-hover:from-saffron/40 group-hover:to-deepSaffron/60 transition-all">
                    <span className="text-saffron font-rozha group-hover:text-sandalwood/90 transition-colors">{text.title.charAt(0)}</span>
                  </div>
                  <div className="flex-1 mr-4">
                    <h3 className="font-rozha text-lg group-hover:text-saffron transition-colors">{text.title}</h3>
                    <p className="text-sm text-foreground/70 line-clamp-1">{text.description}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-saffron opacity-50 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                  
                  <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-gradient-to-r from-saffron/80 to-deepSaffron/50 group-hover:w-full transition-all duration-500 ease-out"></div>
                </Link>
              ))}
            </div>
          )
        )}
      </div>
      
      {/* Footer */}
      <footer className="mt-auto py-8 px-4 border-t-2 border-border bg-gradient-to-r from-secondary/50 to-secondary/20">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center shadow-lg">
                <span className="text-sandalwood/90 font-semibold text-sm">वे</span>
              </div>
              <span className="font-rozha text-2xl text-gradient-rudraksha">Veda AI</span>
            </div>
            
            <div className="text-sm text-foreground/70">
              &copy; {new Date().getFullYear()} Veda AI ज्ञान कोष | <span className="font-kalam">Preserving the Ancient Wisdom of Hindu Scriptures</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Category;


import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="font-rozha text-4xl mb-6 text-rudraksha">About Veda AI <span className="text-saffron">ज्ञान कोष</span></h1>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-lg">
              Veda AI ज्ञान कोष (Knowledge Repository) is a platform designed to make the ancient wisdom of Hindu sacred texts accessible to everyone through the power of artificial intelligence.
            </p>
            
            <h2 className="font-rozha text-2xl mt-8 mb-4 text-rudraksha">Our Mission</h2>
            <p>
              Our mission is to preserve, promote, and make accessible the timeless wisdom contained in the ancient Hindu scriptures. By leveraging modern technology, we aim to bridge the gap between these ancient texts and contemporary seekers of knowledge.
            </p>
            
            <h2 className="font-rozha text-2xl mt-8 mb-4 text-rudraksha">The Collection</h2>
            <p>
              Our digital library includes a comprehensive collection of Hindu sacred texts, including:
            </p>
            <ul className="list-disc pl-5 space-y-2">
              <li><strong className="text-saffron">Vedas:</strong> The oldest scriptures of Hinduism including Rigveda, Samaveda, Yajurveda, and Atharvaveda.</li>
              <li><strong className="text-saffron">Puranas:</strong> Ancient texts containing narratives of the history of the universe from creation to destruction.</li>
              <li><strong className="text-saffron">Epics:</strong> The Ramayana and the Mahabharata, including the Bhagavad Gita.</li>
              <li><strong className="text-saffron">Upanishads:</strong> Philosophical texts that form the theoretical basis for Hinduism.</li>
              <li><strong className="text-saffron">Other Texts:</strong> Including various other important religious and philosophical works.</li>
            </ul>
            
            <h2 className="font-rozha text-2xl mt-8 mb-4 text-rudraksha">How It Works</h2>
            <p>
              Veda AI uses advanced artificial intelligence to help you explore these texts and find answers to your questions. Simply navigate to a text of interest and use the chat interface to ask questions. Our AI will provide insights and information based on the selected text.
            </p>
            
            <div className="flex justify-center mt-10">
              <Button asChild className="bg-saffron hover:bg-deepSaffron text-white px-8 py-6">
                <Link to="/explore">Start Exploring Now</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="mt-auto py-8 px-4 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center">
                <span className="text-white font-semibold text-xs">वे</span>
              </div>
              <span className="font-rozha text-lg">Veda AI</span>
            </div>
            
            <div className="text-sm text-foreground/70">
              &copy; {new Date().getFullYear()} Veda AI ज्ञान कोष | All Rights Reserved
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;


import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, Share2, Bookmark, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';
import ChatInterface from '@/components/ChatInterface';
import { getCategoryById, getTextById } from '@/utils/data';
import { useToast } from '@/hooks/use-toast';

const TextDetail = () => {
  const { categoryId, textId } = useParams<{ categoryId: string, textId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const category = categoryId ? getCategoryById(categoryId) : undefined;
  const text = categoryId && textId ? getTextById(categoryId, textId) : undefined;
  
  useEffect(() => {
    if (!category || !text) {
      toast({
        title: "Text not found",
        description: "The text you're looking for doesn't exist.",
        variant: "destructive"
      });
      navigate('/');
    }
  }, [category, text, navigate, toast]);
  
  if (!category || !text) {
    return null;
  }

  const handleShareClick = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "Link copied",
      description: "The link to this text has been copied to your clipboard.",
    });
  };

  const handleBookmarkClick = () => {
    toast({
      title: "Text bookmarked",
      description: `${text.title} has been added to your saved texts.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container py-8 animate-fade-in">
        <div className="flex flex-col space-y-8">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              className="hover:bg-saffron/10 hover:text-saffron transition-colors flex items-center" 
              onClick={() => navigate(-1)}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to {category.name}
            </Button>
            
            <div className="ml-auto flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                className="border-kashmir/30 hover:border-saffron/50 hover:bg-saffron/10"
                onClick={handleShareClick}
              >
                <Share2 className="h-4 w-4 mr-2 text-saffron" />
                Share
              </Button>
              
              <Button 
                variant="outline" 
                size="sm"
                className="border-kashmir/30 hover:border-saffron/50 hover:bg-saffron/10"
                onClick={handleBookmarkClick}
              >
                <Bookmark className="h-4 w-4 mr-2 text-saffron" />
                Save
              </Button>
            </div>
          </div>
          
          <div className="ornate-divider"></div>
          
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <div className="w-full md:w-1/3 lg:w-1/4">
              <div className="rounded-lg overflow-hidden shadow-lg bg-gradient-to-br from-kashmir/10 to-sandalwood/20 border-2 border-kashmir/30 p-6">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center mb-4">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                
                <h2 className="text-xl font-bold text-center mb-4 font-rozha text-gradient-rudraksha">{text.title}</h2>
                
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <div className="w-2 h-2 rounded-full bg-saffron mr-2"></div>
                    <span className="text-foreground/80">Part of:</span> 
                    <span className="ml-2 font-medium">{category.name}</span>
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <div className="w-2 h-2 rounded-full bg-saffron mr-2"></div>
                    <span className="text-foreground/80">Origin:</span> 
                    <span className="ml-2 font-medium">Ancient India</span>
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <div className="w-2 h-2 rounded-full bg-saffron mr-2"></div>
                    <span className="text-foreground/80">Language:</span> 
                    <span className="ml-2 font-medium">Sanskrit</span>
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <div className="w-2 h-2 rounded-full bg-saffron mr-2"></div>
                    <span className="text-foreground/80">Format:</span> 
                    <span className="ml-2 font-medium">Prose & Verse</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-kashmir/30">
                  <div className="flex justify-between text-sm text-foreground/60">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>5-10 min read</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>Last updated Apr 2025</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="w-full md:w-2/3 lg:w-3/4">
              <div className="mb-8">
                <h1 className="font-rozha text-4xl md:text-5xl mb-4 text-gradient-rudraksha">{text.title}</h1>
                <p className="text-lg text-saffron mb-4">From the sacred {category.name}</p>
              </div>
              
              <div className="ornate-border mb-8 bg-secondary/10 backdrop-blur-sm hover:border-saffron/70 transition-all duration-300">
                <p className="text-lg text-foreground/80 p-6 leading-relaxed">{text.description}</p>
              </div>
              
              <h2 className="font-rozha text-2xl mb-6 flex items-center gap-3">
                <div className="w-1.5 h-8 bg-gradient-to-b from-saffron to-deepSaffron rounded-full"></div>
                Explore the Wisdom of {text.title}
              </h2>
              
              <ChatInterface textId={text.id} textTitle={text.title} />
            </div>
          </div>
        </div>
      </div>
      
      <footer className="mt-auto py-8 px-4 border-t-2 border-border bg-gradient-to-r from-secondary/30 to-secondary/10">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center">
                <span className="text-white font-semibold text-sm">वे</span>
              </div>
              <span className="font-rozha text-2xl">Veda AI</span>
            </div>
            
            <div className="text-sm text-foreground/70">
              &copy; {new Date().getFullYear()} Veda AI ज्ञान कोष | Preserving the Ancient Wisdom of Hindu Scriptures
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TextDetail;

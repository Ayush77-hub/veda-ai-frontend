
import React from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import Navbar from '@/components/Navbar';
import CategoryCard from '@/components/CategoryCard';
import { getAllCategories } from '@/utils/data';

const Explore = () => {
  const allCategories = getAllCategories();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container py-8">
        <h1 className="font-rozha text-3xl md:text-4xl mb-6 text-rudraksha">Explore All Granthas</h1>
        
        <div className="relative mb-8 max-w-xl">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground/50" size={18} />
          <Input 
            className="pl-10"
            placeholder="Search for a specific text..."
            // In a real app, we'd implement search functionality here
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allCategories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
      
      {/* Footer */}
      <footer className="mt-auto py-8 px-4 border-t border-border">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center">
                <span className="text-white font-semibold text-xs">वे</span>
              </div>
              <span className="font-rozha text-lg">Veda AI</span>
            </div>
            
            <div className="text-sm text-foreground/70">
              &copy; {new Date().getFullYear()} Veda AI ज्ञान कोष | All Rights Reserved
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Explore;


export interface Text {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;  // optional image URL for the text
}

export interface Category {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;  // optional image URL for the category
  texts: Text[];
}

export const categories: Category[] = [
  {
    id: 'vedas',
    name: 'Vedas',
    description: 'The oldest sacred texts of Hinduism composed in Vedic Sanskrit, considered to be revelations seen by ancient sages.',
    imageUrl: '/images/vedas.jpg',
    texts: [
      { 
        id: 'rigveda', 
        title: 'RigVeda', 
        description: 'The oldest of the sacred books of Hinduism, containing a collection of 1,028 hymns dedicated to the gods.'
      },
      { 
        id: 'samaveda', 
        title: 'SamVeda', 
        description: 'Contains melodies and chants for rituals, largely derived from the Rigveda but arranged for liturgical purposes.'
      },
      { 
        id: 'yajurveda', 
        title: 'YajurVeda', 
        description: 'Contains prose mantras for worship and rituals, focusing on the practical aspects of religious ceremonies.'
      },
      { 
        id: 'atharvaveda', 
        title: 'AtharvaVeda', 
        description: 'A collection of spells against enemies, sorcerers, diseases and mistakes during rituals. It also contains philosophical hymns.'
      }
    ]
  },
  {
    id: 'puranas',
    name: 'Puranas',
    description: 'Ancient texts eulogizing various deities through divine stories, containing narratives of creation, philosophy, and geography.',
    imageUrl: '/images/puranas.jpg',
    texts: [
      { 
        id: 'bhagwat-puran', 
        title: 'Bhagwat Puran', 
        description: 'Contains the story of Krishna and the Bhagavata theology, promoting devotion to Lord Vishnu.'
      },
      { 
        id: 'shiv-puran', 
        title: 'Shiv Puran', 
        description: 'Glorifies Lord Shiva and narrates tales of his divine acts and manifestations.'
      },
      { 
        id: 'vishnu-puran', 
        title: 'Vishnu Puran', 
        description: 'Narrates tales of Lord Vishnu and his avatars, containing ancient Indian wisdom and cosmology.'
      },
      { 
        id: 'brahma-puran', 
        title: 'Brahma Puran', 
        description: 'Contains the knowledge narrated by Lord Brahma, describing the creation of the universe.'
      },
      { 
        id: 'agni-puran', 
        title: 'Agni Puran', 
        description: 'Contains information about Lord Vishnu, weapons, medicine, grammar, and various other subjects.'
      },
      { 
        id: 'narad-puran', 
        title: 'Narad Puran', 
        description: 'Narrated by sage Narada, explaining worship rituals and the path to spiritual liberation.'
      },
      { 
        id: 'garuda-puran', 
        title: 'Garuda Puran', 
        description: 'Narrated by Lord Vishnu to Garuda about afterlife, funeral rites, and the journey of the soul.'
      },
      { 
        id: 'ling-puran', 
        title: 'Ling Puran', 
        description: 'Glorifies Lord Shiva in the form of a Linga (symbolic representation) and describes his divine qualities.'
      },
      { 
        id: 'padma-puran', 
        title: 'Padma Puran', 
        description: 'Named after the lotus in which Brahma appeared, covering various religious and social topics.'
      },
      { 
        id: 'skand-puran', 
        title: 'Skand Puran', 
        description: 'Largest Purana named after Skanda (Kartikeya), son of Shiva, containing extensive religious teachings.'
      },
      { 
        id: 'brahmand-puran', 
        title: 'Brahmand Puran', 
        description: 'Describes the universe and creation theories in detail with cosmological insights.'
      },
      { 
        id: 'bhavishya-puran', 
        title: 'Bhavishya Puran', 
        description: 'Contains prophecies about future events and kings, along with religious instructions.'
      },
      { 
        id: 'markandya-puran', 
        title: 'Markandya Puran', 
        description: 'Contains the famous Devi Mahatmya glorifying the Divine Mother and her manifestations.'
      },
      { 
        id: 'matsya-puran', 
        title: 'Matsya Puran', 
        description: 'Named after Lord Vishnu\'s fish avatar, containing ancient wisdom delivered during the great flood.'
      },
      { 
        id: 'kurma-puran', 
        title: 'Kurma Puran', 
        description: 'Named after Lord Vishnu\'s turtle avatar, containing discourse between Vishnu and sages.'
      },
      { 
        id: 'varah-puran', 
        title: 'Varah Puran', 
        description: 'Named after Lord Vishnu\'s boar avatar, focusing on Earth\'s rescue from the cosmic waters.'
      },
      { 
        id: 'vaman-puran', 
        title: 'Vaman Puran', 
        description: 'Named after Lord Vishnu\'s dwarf avatar, detailing his triumph over King Bali.'
      },
      { 
        id: 'brahma-vaivarta-puran', 
        title: 'BrahmVaivarta Puran', 
        description: 'Glorifies Radha and Krishna, describing their divine pastimes and spiritual significance.'
      },
      { 
        id: 'vayu-puran', 
        title: 'Vayu Puran', 
        description: 'Named after the deity Vayu (wind), containing ancient genealogies and descriptions of cosmic cycles.'
      },
      { 
        id: 'narsimha-puran', 
        title: 'Narsimha Puran', 
        description: 'Narrates the story of Narasimha avatar of Lord Vishnu, depicting his protection of devotees.'
      }
    ]
  },
  {
    id: 'epics',
    name: 'Epics',
    description: 'The major Sanskrit epics of ancient India, containing profound philosophical and spiritual insights through narrative stories.',
    imageUrl: '/images/epics.jpg',
    texts: [
      { 
        id: 'mahabharat', 
        title: 'Mahabharat', 
        description: 'The epic story of the Kurukshetra War between the Kauravas and the Pandavas, containing the Bhagavad Gita.'
      },
      { 
        id: 'ramayan', 
        title: 'Ramayan', 
        description: 'The story of Lord Rama\'s life, including his exile and the abduction of his wife Sita by Ravana.'
      },
      { 
        id: 'ramcharitmanas', 
        title: 'Ramcharitmanas', 
        description: 'A retelling of the Ramayana in Awadhi by the sage Tulsidas, emphasizing devotion to Lord Rama.'
      },
      { 
        id: 'anand-ramayan', 
        title: 'Anand Ramayan', 
        description: 'Another version of the Ramayana focusing on the bliss aspect of Lord Rama\'s story and teachings.'
      }
    ]
  },
  {
    id: 'upanishads',
    name: 'Upanishads',
    description: 'Philosophical texts that form the theoretical basis for Hinduism, focusing on the nature of reality and the self.',
    imageUrl: '/images/upanishads.jpg',
    texts: [
      { 
        id: 'vedant-darshan', 
        title: 'Vedant Darshan', 
        description: 'A school of Hindu philosophy based on the teachings of the Upanishads, exploring the nature of ultimate reality.'
      },
      { 
        id: 'brahmasutra', 
        title: 'Brahmasutra', 
        description: 'A treatise on the philosophy of the Upanishads by Sage Badarayana, systematizing Vedantic thought.'
      }
    ]
  },
  {
    id: 'garthas',
    name: 'Garthas',
    description: 'Ancient sacred hymns and poetic verses that contain spiritual wisdom and divine knowledge from the Vedic tradition.',
    imageUrl: '/images/garthas.jpg',
    texts: [
      { 
        id: 'gathas-zarathustra', 
        title: 'Gathas of Zarathustra', 
        description: 'The hymns composed by Zarathustra (Zoroaster), forming the core of the Zoroastrian faith and philosophy.'
      },
      { 
        id: 'gathic-avestan', 
        title: 'Gathic Avestan', 
        description: 'The oldest texts of the Avestan language that contain the sacred hymns of ancient Indo-Iranian traditions.'
      },
      { 
        id: 'yasna-haptanghaiti', 
        title: 'Yasna Haptanghaiti', 
        description: 'Seven-chapter hymns composed in the ancient Gathic dialect, dedicated to Ahura Mazda and other divine entities.'
      },
      { 
        id: 'buddhist-gathas', 
        title: 'Buddhist Gathas', 
        description: 'Versified teachings found in Buddhist literature that contain moral and spiritual instructions of the Buddha.'
      },
      { 
        id: 'vedic-gathas', 
        title: 'Vedic Gathas', 
        description: 'Ancient hymns from the Rigveda that are structured in metrical verses, praising deities and natural phenomena.'
      }
    ]
  },
  {
    id: 'other-texts',
    name: 'Other Sacred Texts',
    description: 'Other important Hindu religious and philosophical texts that provide guidance on dharma, spirituality, and cosmic knowledge.',
    imageUrl: '/images/other-texts.jpg',
    texts: [
      { 
        id: 'bhagavad-gita', 
        title: 'Shrimad Bhagvad Geeta', 
        description: 'A 700-verse Hindu scripture that is part of the epic Mahabharata, containing the spiritual discourse of Krishna to Arjuna.'
      },
      { 
        id: 'manusmriti', 
        title: 'Manusmriti', 
        description: 'An ancient legal text and constitution among the many Dharmaśāstras of Hinduism, establishing societal norms.'
      },
      { 
        id: 'devi-bhagwat', 
        title: 'Devi Bhagwat', 
        description: 'A text that celebrates the Divine Feminine, narrating the glories and manifestations of the Goddess.'
      },
      { 
        id: 'durga-saptashati', 
        title: 'Durga Saptashati', 
        description: 'A Hindu text describing the victory of the goddess Durga over the demon Mahishasura, also known as Devi Mahatmya.'
      },
      { 
        id: 'kalki-puran', 
        title: 'Kalki Puran', 
        description: 'Describes the tenth and final incarnation of Vishnu who will appear at the end of Kali Yuga.'
      },
      { 
        id: 'vimanika-shaster', 
        title: 'Vimanika Shaster', 
        description: 'Text on ancient aerospace technology, describing various types of flying machines in ancient India.'
      },
      { 
        id: 'narayan-kwach', 
        title: 'Narayan Kwach', 
        description: 'A protective armor in the form of a hymn, believed to shield the reciter from negative energies.'
      },
      { 
        id: 'aryabhatiya', 
        title: 'Aryabhatiya', 
        description: 'Ancient Indian mathematical text by Aryabhata, containing groundbreaking astronomical and mathematical concepts.'
      },
      { 
        id: 'bhrigu-samhita', 
        title: 'Bhrigu Samhita', 
        description: 'Ancient astrological text attributed to sage Bhrigu, containing detailed astrological predictions.'
      },
      { 
        id: 'ravan-samhita', 
        title: 'रावण सहिंता', 
        description: 'Text attributed to Ravana with knowledge of astrology, medicine, and various occult sciences.'
      }
    ]
  }
];

export const getAllCategories = (): Category[] => {
  return categories;
};

export const getCategoryById = (id: string): Category | undefined => {
  return categories.find(category => category.id === id);
};

export const getTextById = (categoryId: string, textId: string): Text | undefined => {
  const category = getCategoryById(categoryId);
  if (!category) return undefined;
  return category.texts.find(text => text.id === textId);
};

// Sample responses for the chatbot - in a real implementation, this would connect to an AI model
export const getSampleResponse = (textId: string, query: string): string => {
  // Customized responses based on the text being queried
  const textResponses: Record<string, string[]> = {
    'bhagavad-gita': [
      "The Bhagavad Gita teaches us that we should perform our duties without attachment to the results.",
      "In chapter 2 of the Bhagavad Gita, Lord Krishna explains the immortality of the soul: 'For the soul there is neither birth nor death at any time. It has not come into being, does not come into being, and will not come into being. It is unborn, eternal, ever-existing, and primeval.'",
      "The Gita emphasizes the importance of yoga as a means to control the mind and attain spiritual enlightenment.",
      "Lord Krishna reveals his cosmic form to Arjuna in the eleventh chapter, demonstrating his divine nature."
    ],
    'mahabharat': [
      "The Mahabharata is one of the two major Sanskrit epics of ancient India, the other being the Ramayana.",
      "The central story of the Mahabharata is the Kurukshetra War between the Kauravas and the Pandavas.",
      "The Bhagavad Gita is a part of the Mahabharata, contained in the Bhishma Parva.",
      "The Mahabharata contains approximately 100,000 verses, making it the longest epic poem known."
    ],
    'ramayan': [
      "The Ramayana narrates the life of Rama, who is considered an avatar of the Hindu god Vishnu.",
      "Hanuman, the monkey deity, is a central character who helped Rama rescue his wife Sita.",
      "The Ramayana emphasizes the importance of dharma and righteous living.",
      "The epic was composed by the sage Valmiki, who is revered as the first poet of Sanskrit literature."
    ],
    'gathas-zarathustra': [
      "The Gathas of Zarathustra are seventeen hymns believed to be composed by Zoroaster himself, containing the core theological teachings of Zoroastrianism.",
      "These hymns emphasize the worship of Ahura Mazda and the importance of good thoughts, good words, and good deeds.",
      "The Gathas are written in an ancient form of Avestan language that is different from the rest of the Avestan texts.",
      "They contain profound philosophical reflections on the nature of existence, truth, and moral choices."
    ]
  };

  // Get specific responses for the text if available
  const specificResponses = textResponses[textId];
  
  if (specificResponses && specificResponses.length > 0) {
    // Return a random response from the available ones
    const randomIndex = Math.floor(Math.random() * specificResponses.length);
    return specificResponses[randomIndex];
  }
  
  // Generic response for texts without specific responses
  return `This is a response about ${textId} for your query: "${query}". In the complete implementation, this would provide specific knowledge from the selected sacred text based on AI analysis.`;
};

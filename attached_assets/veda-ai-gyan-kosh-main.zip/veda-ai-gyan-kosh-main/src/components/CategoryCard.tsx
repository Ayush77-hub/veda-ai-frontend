
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { Category } from '@/utils/data';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link 
      to={`/category/${category.id}`}
      className="hindu-card group relative overflow-hidden flex flex-col"
    >
      <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-gradient-to-br from-saffron/20 to-saffron/5 group-hover:scale-125 transition-transform duration-500"></div>
      
      <h3 className="font-rozha text-2xl mb-2 text-rudraksha group-hover:text-saffron transition-colors">
        {category.name}
      </h3>
      
      <p className="text-sm text-foreground/80 mb-4">
        {category.description}
      </p>
      
      <div className="mt-auto flex justify-between items-center">
        <span className="text-xs text-muted-foreground">
          {category.texts.length} texts
        </span>
        <span className="flex items-center text-sm text-saffron group-hover:gap-2 transition-all">
          Explore <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </span>
      </div>

      <div className="absolute bottom-0 left-0 h-1 w-0 bg-gradient-to-r from-saffron to-deepSaffron group-hover:w-full transition-all duration-300"></div>
    </Link>
  );
};

export default CategoryCard;

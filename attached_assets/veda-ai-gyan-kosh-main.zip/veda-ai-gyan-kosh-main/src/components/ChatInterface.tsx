
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Info, FileText, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { getSampleResponse } from '@/utils/data';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip } from '@/components/ui/tooltip';
import {
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  message: string;
  timestamp: Date;
}

interface ChatInterfaceProps {
  textId: string;
  textTitle: string;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ textId, textTitle }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'ai',
      message: `🙏 Namaste! I am your guide to the ancient wisdom of ${textTitle}. What would you like to know about this sacred text?`,
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    setTimeout(() => {
      inputRef.current?.focus();
    }, 500);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      message: input,
      timestamp: new Date()
    };
    
    setMessages([...messages, userMessage]);
    setInput('');
    setIsLoading(true);
    
    // Simulate AI response delay (would be replaced with actual API call)
    setTimeout(() => {
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        message: getSampleResponse(textId, input),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
      
      toast({
        title: "New insight available",
        description: "The AI has shared wisdom from the sacred text.",
        variant: "default",
      });
    }, 1500);
  };

  const suggestedQuestions = [
    "What is the main theme of this text?",
    "Who composed this sacred text?",
    "What spiritual lessons does it teach?",
    "Can you explain an important story from this text?"
  ];

  return (
    <div className="flex flex-col h-[70vh] md:h-[60vh] lg:h-[65vh] rounded-lg border-2 border-kashmir/40 overflow-hidden shadow-lg bg-gradient-to-b from-background via-secondary/20 to-secondary/30">
      <div className="p-4 border-b-2 border-kashmir/40 bg-gradient-to-r from-saffron/20 to-deepSaffron/20 backdrop-blur-sm">
        <div className="flex items-center justify-between">
          <h2 className="font-rozha text-lg flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gradient-to-r from-saffron to-deepSaffron animate-pulse"></div>
            <span className="text-gradient-rudraksha">Conversing with {textTitle}</span>
          </h2>
          <div className="flex gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-saffron/20">
                    <FileText className="h-4 w-4 text-saffron" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View Text Details</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-saffron/20">
                    <Bookmark className="h-4 w-4 text-saffron" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Save Conversation</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-saffron/20">
                    <Info className="h-4 w-4 text-saffron" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>About This Text</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-4 space-y-4 bg-background/80">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4 animate-fade-in`}
          >
            {msg.sender === 'ai' && (
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-deepSaffron to-saffron flex items-center justify-center mr-2 shadow-md">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
            )}
            <div 
              className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                msg.sender === 'user' 
                  ? 'bg-gradient-to-r from-saffron to-deepSaffron text-white rounded-tr-none shadow-md' 
                  : 'bg-gradient-to-br from-secondary/80 to-background/90 text-foreground rounded-tl-none border-2 border-kashmir/30 shadow-sm'
              }`}
            >
              <p className="text-sm md:text-base">{msg.message}</p>
              <p className="text-xs mt-2 opacity-70 text-right">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
            {msg.sender === 'user' && (
              <div className="w-10 h-10 rounded-full bg-accent ml-2 flex items-center justify-center shadow-md">
                <span className="text-xs font-semibold text-accent-foreground">You</span>
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start mb-4">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-deepSaffron to-saffron flex items-center justify-center mr-2 shadow-md">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div className="bg-gradient-to-br from-secondary/80 to-background/90 text-foreground rounded-2xl rounded-tl-none border-2 border-kashmir/30 shadow-sm px-6 py-4">
              <div className="flex space-x-2">
                <div className="w-2 h-2 rounded-full bg-saffron animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-saffron animate-pulse delay-150"></div>
                <div className="w-2 h-2 rounded-full bg-saffron animate-pulse delay-300"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </ScrollArea>
      
      {messages.length === 1 && !isLoading && (
        <div className="px-4 py-3 bg-background/60">
          <h3 className="text-sm font-medium text-saffron mb-2">Suggested questions:</h3>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((question, index) => (
              <button
                key={index}
                className="text-xs px-3 py-1.5 rounded-full bg-secondary/80 hover:bg-saffron/20 text-foreground/80 transition-colors border border-kashmir/30"
                onClick={() => {
                  setInput(question);
                  inputRef.current?.focus();
                }}
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="border-t-2 border-kashmir/40 p-4 bg-secondary/30 backdrop-blur-sm">
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about this sacred text..."
            className="flex-1 border-kashmir/40 focus-visible:ring-saffron bg-background/80 shadow-inner"
            disabled={isLoading}
          />
          <Button 
            type="submit" 
            className="bg-gradient-to-r from-saffron to-deepSaffron hover:from-deepSaffron hover:to-rudraksha text-white shadow-md transition-all duration-300" 
            disabled={isLoading}
          >
            <Send className="h-4 w-4" />
            <span className="sr-only">Send message</span>
          </Button>
        </div>
        <div className="text-xs text-center mt-2 text-foreground/50">
          Tap into the ancient wisdom of Hindu scriptures through Veda AI
        </div>
      </form>
    </div>
  );
};

export default ChatInterface;

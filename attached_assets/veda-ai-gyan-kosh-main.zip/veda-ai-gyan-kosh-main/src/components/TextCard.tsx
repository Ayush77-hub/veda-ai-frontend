
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, BookOpen, ArrowRight, Sparkles } from 'lucide-react';
import { Text } from '@/utils/data';

interface TextCardProps {
  categoryId: string;
  text: Text;
}

const TextCard: React.FC<TextCardProps> = ({ categoryId, text }) => {
  return (
    <Link 
      to={`/text/${categoryId}/${text.id}`}
      className="hindu-card group hover:scale-[1.02] transition-all duration-300 flex flex-col h-full relative overflow-hidden"
    >
      {/* Decorative Elements */}
      <div className="absolute -right-12 -top-12 w-24 h-24 rounded-full bg-gradient-to-br from-saffron/10 to-deepSaffron/5 group-hover:scale-150 transition-all duration-700 ease-out"></div>
      <div className="absolute -left-12 -bottom-12 w-32 h-32 rounded-full bg-gradient-to-tr from-rudraksha/10 to-kashmir/5 group-hover:scale-150 transition-all duration-700 ease-out delay-100"></div>
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-saffron/30 to-deepSaffron/60 flex items-center justify-center shadow-md group-hover:shadow-saffron/20 transition-all">
            <BookOpen className="h-4 w-4 text-sandalwood/90" />
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="h-3 w-3 text-rudraksha/60 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="w-2 h-2 rounded-full bg-rudraksha/50 group-hover:bg-rudraksha transition-colors"></div>
          </div>
        </div>
        
        <h3 className="font-rozha text-xl mb-2 group-hover:text-saffron transition-colors">
          {text.title}
        </h3>
        
        <p className="text-sm text-foreground/80 mb-6 line-clamp-3 flex-grow">
          {text.description}
        </p>
        
        <div className="flex items-center justify-between text-sm text-saffron mt-auto pt-3 border-t border-kashmir/30 relative">
          <div className="flex items-center">
            <MessageSquare className="h-4 w-4 mr-1" />
            <span>AI Insights</span>
          </div>
          <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all" />
          
          {/* Animated border */}
          <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-gradient-to-r from-deepSaffron/80 to-saffron group-hover:w-full transition-all duration-500 ease-out"></div>
        </div>
      </div>
    </Link>
  );
};

export default TextCard;


import React from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

const Navbar: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-sm bg-background/80 border-b border-border">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-saffron to-deepSaffron flex items-center justify-center">
              <span className="text-white font-semibold text-sm">वे</span>
            </div>
            <h1 className="font-rozha text-2xl sm:text-3xl tracking-wide text-saffron">Veda AI <span className="text-sm font-poppins text-foreground/70">ज्ञान कोष</span></h1>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-4">
          <Link to="/" className="text-foreground/70 hover:text-saffron transition-colors">
            Home
          </Link>
          <Link to="/about" className="text-foreground/70 hover:text-saffron transition-colors">
            About
          </Link>
          <Button asChild variant="outline" className="border-saffron text-saffron hover:text-saffron/80 hover:bg-saffron/10">
            <Link to="/explore">
              Explore Granthas
            </Link>
          </Button>
        </nav>

        {/* Mobile Navigation */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" className="md:hidden" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Open menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="bg-background/95 backdrop-blur-lg border-l border-saffron/30">
            <div className="flex flex-col space-y-4 mt-8">
              <Link to="/" className="text-lg font-medium hover:text-saffron transition-colors">
                Home
              </Link>
              <Link to="/about" className="text-lg font-medium hover:text-saffron transition-colors">
                About
              </Link>
              <Link to="/explore" className="text-lg font-medium hover:text-saffron transition-colors">
                Explore Granthas
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};

export default Navbar;
